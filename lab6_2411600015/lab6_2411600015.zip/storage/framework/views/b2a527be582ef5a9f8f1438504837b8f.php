

<?php $__env->startSection('content'); ?>

<div class="container">

    <h1>Edit Course</h1>

    <form method="POST" action="<?php echo e(route('courses.update', $course)); ?>">

        <?php echo method_field('PUT'); ?>

        <?php echo $__env->make('courses._form', [
            'course' => $course,
            'buttonText' => 'Update Course'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/courses/edit.blade.php ENDPATH**/ ?>