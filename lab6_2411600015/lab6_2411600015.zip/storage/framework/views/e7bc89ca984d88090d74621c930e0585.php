

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center pb-2 mb-4 border-bottom">

        <div>
            <h2 class="mb-1">My Courses & Grades</h2>

            <p class="text-muted mb-0">
                View and manage your courses and grades.
            </p>
        </div>

        <a href="<?php echo e(route('courses.create')); ?>" class="btn btn-primary">
            + Add Course
        </a>

    </div>


    <!-- Filters -->
    <div class="card shadow-sm mb-4">

        <div class="card-body">

            <form method="GET" action="<?php echo e(route('courses.index')); ?>">

                <div class="row g-3 align-items-end">

                    <!-- Category -->
                    <div class="col-md-4">

                        <label for="category" class="form-label">
                            Category
                        </label>

                        <select
                            id="category"
                            name="category"
                            class="form-select"
                        >

                            <option value="">
                                All Categories
                            </option>

                            <option
                                value="Major"
                                <?php if(request('category') === 'Major'): echo 'selected'; endif; ?>
                            >
                                Major
                            </option>

                            <option
                                value="Minor"
                                <?php if(request('category') === 'Minor'): echo 'selected'; endif; ?>
                            >
                                Minor
                            </option>

                            <option
                                value="Gen Ed"
                                <?php if(request('category') === 'Gen Ed'): echo 'selected'; endif; ?>
                            >
                                Gen Ed
                            </option>

                            <option
                                value="Elective"
                                <?php if(request('category') === 'Elective'): echo 'selected'; endif; ?>
                            >
                                Elective
                            </option>

                        </select>

                    </div>


                    <!-- Search -->
                    <div class="col-md-5">

                        <label for="search" class="form-label">
                            Search
                        </label>

                        <input
                            type="text"
                            id="search"
                            name="search"
                            class="form-control"
                            value="<?php echo e(request('search')); ?>"
                            placeholder="Search by name, code, or instructor..."
                        >

                    </div>


                    <!-- Apply -->
                    <div class="col-md-3">

                        <button
                            type="submit"
                            class="btn btn-primary w-100"
                        >
                            Apply
                        </button>

                    </div>

                </div>

            </form>

        </div>

    </div>


    <!-- Course Table -->
    <div class="card shadow-sm">

        <div class="card-header d-flex justify-content-between align-items-center">

            <h5 class="mb-0">
                Courses
            </h5>

            <span class="text-muted">
                <?php echo e($courses->count()); ?> course(s)
            </span>

        </div>


        <div class="card-body">

            <?php if($courses->count()): ?>

                <div class="table-responsive">

                    <table class="table table-striped table-hover align-middle">

                        <thead>

                            <tr>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Category</th>
                                <th>Units</th>
                                <th>Instructor</th>
                                <th>Grade</th>
                                <th>Attendance</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>

                        </thead>


                        <tbody>

                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>

                                    <td>
                                        <?php echo e($course->course_code); ?>

                                    </td>

                                    <td>
                                        <?php echo e($course->course_name); ?>

                                    </td>

                                    <td>
                                        <?php echo e($course->category); ?>

                                    </td>

                                    <td>
                                        <?php echo e($course->units); ?>

                                    </td>

                                    <td>
                                        <?php echo e($course->instructor); ?>

                                    </td>

                                    <td>
                                        <?php echo e(number_format($course->grade, 2)); ?>

                                    </td>

                                    <td>
                                        <?php echo e($course->attendance_rate); ?>%
                                    </td>

                                    <td>

                                        <?php if($course->status === 'Passing'): ?>

                                            <span class="badge bg-success">
                                                Passing
                                            </span>

                                        <?php elseif($course->status === 'At Risk'): ?>

                                            <span class="badge bg-warning text-dark">
                                                At Risk
                                            </span>

                                        <?php else: ?>

                                            <span class="badge bg-danger">
                                                Failing
                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <td>

                                        <div class="d-flex gap-1">

                                            <a
                                                href="<?php echo e(route('courses.show', $course)); ?>"
                                                class="btn btn-sm btn-info"
                                            >
                                                View
                                            </a>

                                            <a
                                                href="<?php echo e(route('courses.edit', $course)); ?>"
                                                class="btn btn-sm btn-primary"
                                            >
                                                Edit
                                            </a>

                                            <form
                                                action="<?php echo e(route('courses.destroy', $course)); ?>"
                                                method="POST"
                                            >

                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <button
                                                    type="submit"
                                                    class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Delete this course?')"
                                                >
                                                    Delete
                                                </button>

                                            </form>

                                        </div>

                                    </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>

                </div>

            <?php else: ?>

                <div class="text-center py-5">

                    <h5>No courses found</h5>

                    <p class="text-muted">
                        Try changing your search or category filter.
                    </p>

                    <a
                        href="<?php echo e(route('courses.index')); ?>"
                        class="btn btn-secondary"
                    >
                        Clear Filters
                    </a>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/courses/index.blade.php ENDPATH**/ ?>