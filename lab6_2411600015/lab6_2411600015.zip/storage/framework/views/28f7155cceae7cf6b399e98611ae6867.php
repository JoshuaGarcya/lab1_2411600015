<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>GSCSDA Student Portal</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Your Lab 4 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">

            <a class="navbar-brand fw-bold" href="<?php echo e(route('courses.index')); ?>">
                GSCSDA Student Portal
            </a>

            <button class="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">

                    <?php
                        $unreadNotifications = Auth::user()->unreadNotifications;
                    ?>

                    <!-- Notification bell -->
                    <li class="nav-item dropdown me-3">
                        <a class="nav-link position-relative text-white"
                           href="#"
                           id="notificationBell"
                           role="button"
                           data-bs-toggle="dropdown"
                           aria-expanded="false"
                           aria-label="Notifications">
                            &#128276;
                            <span id="bell-count"
                                  class="badge rounded-pill bg-danger position-absolute top-0 start-100 translate-middle <?php echo e($unreadNotifications->count() ? '' : 'd-none'); ?>">
                                <?php echo e($unreadNotifications->count()); ?>

                            </span>
                        </a>

                        <ul class="dropdown-menu dropdown-menu-end p-0 shadow"
                            style="min-width: 340px;"
                            aria-labelledby="notificationBell">

                            <li class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom">
                                <strong>Notifications</strong>

                                <?php if($unreadNotifications->count()): ?>
                                    <form method="POST" action="<?php echo e(route('notifications.readAll')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-link btn-sm p-0">
                                            Mark all as read
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </li>

                            <?php $__empty_1 = true; $__currentLoopData = $unreadNotifications->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li>
                                    <form method="POST" action="<?php echo e(route('notifications.read', $notification->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item text-wrap py-2 border-bottom">
                                            <div class="fw-semibold">
                                                <?php echo e($notification->data['course_code'] ?? 'Course'); ?>

                                                <?php if(!empty($notification->data['limit_reached'])): ?>
                                                    <span class="badge bg-danger ms-1">Limit reached</span>
                                                <?php else: ?>
                                                    <span class="badge bg-warning text-dark ms-1">Low allowance</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="small text-muted">
                                                <?php echo e($notification->data['message'] ?? ''); ?>

                                            </div>
                                            <div class="small text-muted">
                                                <?php echo e($notification->created_at->diffForHumans()); ?>

                                            </div>
                                        </button>
                                    </form>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="px-3 py-3 text-muted small">
                                    You're all caught up.
                                </li>
                            <?php endif; ?>

                        </ul>
                    </li>

                    <!-- User dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white"
                           href="#"
                           id="userMenu"
                           role="button"
                           data-bs-toggle="dropdown"
                           aria-expanded="false">
                            Welcome, <?php echo e(Auth::user()->name); ?>

                            <?php if(Auth::user()->is_admin): ?>
                                <span class="badge bg-light text-primary ms-1">Admin</span>
                            <?php endif; ?>
                        </a>

                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenu">
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item">Logout</button>
                                </form>
                            </li>
                        </ul>
                    </li>

                </ul>
            </div>
        </div>
    </nav>


    <!-- Main Layout -->
    <div class="container-fluid">
        <div class="row">

            <!-- Sidebar -->
           <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar vh-100 p-3">
    <div class="position-sticky">

        <ul class="nav flex-column">

            <!-- Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                    Dashboard
                </a>
            </li>

            <!-- My Courses -->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('courses.index')); ?>">
                    My Courses & Grades
                </a>
            </li>

            <!-- Add Course -->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('courses.create')); ?>">
                    Add Course
                </a>
            </li>

            <!-- Attendance Log -->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('attendance-transactions.index')); ?>">
                    Attendance Log
                </a>
            </li>

            <?php if(Auth::user()->is_admin): ?>
                <!-- Adjust Count (admin) -->
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('adjustments.create')); ?>">
                        Adjust Count
                    </a>
                </li>
            <?php endif; ?>

            <!-- Reports -->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('reports.index')); ?>">
                    Reports
                </a>
            </li>

            <!-- Logout -->
            <li class="nav-item">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>

                    <button
                        type="submit"
                        class="nav-link text-danger border-0 bg-transparent"
                    >
                        Logout
                    </button>
                </form>
            </li>

        </ul>

    </div>
</nav>


            <!-- Page Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

                <?php echo $__env->yieldContent('content'); ?>

            </main>

        </div>
    </div>


    <!-- Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/layouts/app.blade.php ENDPATH**/ ?>