<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center pb-2 mb-4 border-bottom">
        <div>
            <h2 class="mb-1">Transaction #<?php echo e($transaction->id); ?></h2>
            <p class="text-muted mb-0"><?php echo e($transaction->created_at->format('F d, Y h:i A')); ?></p>
        </div>

        <div class="d-flex gap-2">
            <a href="<?php echo e(route('attendance-transactions.index')); ?>" class="btn btn-secondary">Back to Log</a>

            <?php if(Auth::user()->is_admin): ?>
                <form method="POST"
                      action="<?php echo e(route('attendance-transactions.destroy', $transaction)); ?>"
                      onsubmit="return confirm('Delete this transaction? Its effect on the course will be reversed.');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="row g-4">

        <!-- Transaction details -->
        <div class="col-lg-4">
            <div class="card shadow-sm h-100">
                <div class="card-header"><h5 class="mb-0">Transaction</h5></div>
                <div class="card-body">
                    <p class="mb-2">
                        <strong>Type:</strong>
                        <span class="badge bg-<?php echo e($transaction->type_badge); ?> <?php echo e($transaction->type_badge === 'info' ? 'text-dark' : ''); ?>">
                            <?php echo e($transaction->type_label); ?>

                        </span>
                    </p>
                    <p class="mb-2">
                        <strong>Quantity:</strong>
                        <span class="fw-bold <?php echo e($transaction->quantity > 0 ? 'text-success' : 'text-danger'); ?>">
                            <?php echo e($transaction->signed_quantity); ?>

                        </span>
                    </p>
                    <p class="mb-2"><strong>Reference:</strong> <?php echo e($transaction->reference_number ?? '—'); ?></p>
                    <p class="mb-2"><strong>Reason:</strong> <?php echo e($transaction->reason ?? '—'); ?></p>
                    <p class="mb-0"><strong>Notes:</strong> <?php echo e($transaction->notes ?? '—'); ?></p>
                </div>
            </div>
        </div>

        <!-- Course -->
        <div class="col-lg-4">
            <div class="card shadow-sm h-100">
                <div class="card-header"><h5 class="mb-0">Course</h5></div>
                <div class="card-body">
                    <?php if($transaction->course): ?>
                        <p class="mb-2"><strong>Code:</strong> <?php echo e($transaction->course->course_code); ?></p>
                        <p class="mb-2"><strong>Name:</strong> <?php echo e($transaction->course->course_name); ?></p>
                        <p class="mb-2"><strong>Instructor:</strong> <?php echo e($transaction->course->instructor); ?></p>
                        <p class="mb-2">
                            <strong>Absences remaining now:</strong>
                            <?php echo e($transaction->course->absences_remaining); ?> of <?php echo e($transaction->course->absences_allowed); ?>

                        </p>
                        <p class="mb-3">
                            <strong>Status:</strong>
                            <span class="badge bg-<?php echo e($transaction->course->allowance_status_color); ?> <?php echo e($transaction->course->allowance_status_color === 'warning' ? 'text-dark' : ''); ?>">
                                <?php echo e($transaction->course->allowance_status); ?>

                            </span>
                        </p>
                        <a href="<?php echo e(route('courses.show', $transaction->course)); ?>" class="btn btn-sm btn-primary">
                            View Course
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- User -->
        <div class="col-lg-4">
            <div class="card shadow-sm h-100">
                <div class="card-header"><h5 class="mb-0">Recorded By</h5></div>
                <div class="card-body">
                    <?php if($transaction->user): ?>
                        <p class="mb-2"><strong>Name:</strong> <?php echo e($transaction->user->name); ?></p>
                        <p class="mb-0"><strong>Email:</strong> <?php echo e($transaction->user->email); ?></p>
                    <?php else: ?>
                        <p class="text-muted mb-0">This user account has been deleted.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/attendance/show.blade.php ENDPATH**/ ?>