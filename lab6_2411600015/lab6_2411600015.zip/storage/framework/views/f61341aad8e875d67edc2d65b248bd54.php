<?php $__env->startSection('content'); ?>

<div class="container" style="max-width: 760px;">

    <div class="pb-2 mb-4 border-bottom">
        <h2 class="mb-1">Adjust Absence Count</h2>
        <p class="text-muted mb-0">
            Use this when the instructor's record doesn't match the system. The difference is logged as an adjustment.
        </p>
    </div>

    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="card shadow-sm">
        <div class="card-body">

            <form method="POST" action="<?php echo e(route('adjustments.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="course_id" class="form-label">Course</label>
                    <select id="course_id" name="course_id" class="form-select" required>
                        <option value="">Select a course…</option>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($course->id); ?>" <?php if(old('course_id') == $course->id): echo 'selected'; endif; ?>>
                                <?php echo e($course->course_code); ?> — <?php echo e($course->course_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['course_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label for="system_remaining" class="form-label">System: absences remaining</label>
                        <input type="text" id="system_remaining" class="form-control" value="—" readonly>
                    </div>

                    <div class="col-md-6">
                        <label for="counted_remaining" class="form-label">Recorded: absences remaining</label>
                        <input type="number" id="counted_remaining" name="counted_remaining"
                               class="form-control" min="0" value="<?php echo e(old('counted_remaining')); ?>" required>
                        <?php $__errorArgs = ['counted_remaining'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div id="difference" class="alert alert-secondary py-2 d-none"></div>

                <div class="mb-3">
                    <label for="reason" class="form-label">Reason for adjustment</label>
                    <select id="reason" name="reason" class="form-select" required>
                        <option value="">Select a reason…</option>
                        <?php $__currentLoopData = $reasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($reason); ?>" <?php if(old('reason') === $reason): echo 'selected'; endif; ?>><?php echo e($reason); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="notes" class="form-label">Notes (optional)</label>
                    <textarea id="notes" name="notes" rows="3" maxlength="500"
                              class="form-control"><?php echo e(old('notes')); ?></textarea>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">Save Adjustment</button>
                    <a href="<?php echo e(route('attendance-transactions.index')); ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    (function () {
        const urlTemplate = <?php echo json_encode(route('api.courses.allowance', ['course' => '__ID__'], false)) ?>;
        const course = document.getElementById('course_id');
        const system = document.getElementById('system_remaining');
        const counted = document.getElementById('counted_remaining');
        const diffBox = document.getElementById('difference');
        let systemValue = null;

        function showDifference() {
            if (systemValue === null || counted.value === '') {
                diffBox.classList.add('d-none');
                return;
            }

            const diff = parseInt(counted.value, 10) - systemValue;

            diffBox.classList.remove('d-none');
            diffBox.textContent = diff === 0
                ? 'No difference — nothing to adjust.'
                : 'Difference: ' + (diff > 0 ? '+' : '') + diff + ' (this will be logged as the adjustment).';
        }

        // Load the current system value over AJAX
        function loadAllowance() {
            systemValue = null;
            system.value = '—';
            counted.removeAttribute('max');

            if (!course.value) {
                showDifference();
                return;
            }

            fetch(urlTemplate.replace('__ID__', course.value), {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin'
            })
                .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
                .then(function (json) {
                    systemValue = json.data.remaining;
                    system.value = json.data.remaining + ' of ' + json.data.allowed;
                    counted.max = json.data.allowed;
                    showDifference();
                })
                .catch(function () {
                    system.value = 'Could not load';
                });
        }

        course.addEventListener('change', loadAllowance);
        counted.addEventListener('input', showDifference);

        if (course.value) { loadAllowance(); }
    })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/attendance/adjust.blade.php ENDPATH**/ ?>