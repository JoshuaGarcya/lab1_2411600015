<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center pb-2 mb-4 border-bottom">
        <div>
            <h2 class="mb-1">Attendance Reports</h2>
            <p class="text-muted mb-0"><?php echo e($data['title']); ?></p>
        </div>

        <a href="<?php echo e(route('reports.export', ['report' => $report, 'from' => $from, 'to' => $to])); ?>"
           class="btn btn-outline-primary">
            Export CSV
        </a>
    </div>

    <!-- Report tabs -->
    <ul class="nav nav-tabs mb-4">
        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e($report === $key ? 'active' : ''); ?>"
                   href="<?php echo e(route('reports.index', ['report' => $key, 'from' => $from, 'to' => $to])); ?>">
                    <?php echo e($label); ?>

                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <!-- Date range (movement report only) -->
    <?php if($report === 'movement'): ?>
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('reports.index')); ?>">
                    <input type="hidden" name="report" value="movement">

                    <div class="row g-3 align-items-end">
                        <div class="col-md-3">
                            <label for="from" class="form-label">From</label>
                            <input type="date" id="from" name="from" class="form-control" value="<?php echo e($from); ?>">
                        </div>

                        <div class="col-md-3">
                            <label for="to" class="form-label">To</label>
                            <input type="date" id="to" name="to" class="form-control" value="<?php echo e($to); ?>">
                        </div>

                        <div class="col-md-3">
                            <button type="submit" class="btn btn-primary">Generate</button>
                        </div>
                    </div>

                    <?php if($errors->any()): ?>
                        <div class="text-danger small mt-2"><?php echo e($errors->first()); ?></div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <!-- Summary -->
    <div class="row g-3 mb-4">
        <?php $__currentLoopData = $data['summary']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <p class="text-muted stat-label mb-1"><?php echo e($label); ?></p>
                        <h3 class="stat-value mb-0"><?php echo e($value); ?></h3>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Table -->
    <div class="card shadow-sm">
        <div class="card-body">

            <?php if(count($data['rows'])): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead>
                            <tr>
                                <?php $__currentLoopData = $data['headings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($heading); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $data['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($cell); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted mb-0">Nothing to report for this selection.</p>
            <?php endif; ?>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/reports/index.blade.php ENDPATH**/ ?>