<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>