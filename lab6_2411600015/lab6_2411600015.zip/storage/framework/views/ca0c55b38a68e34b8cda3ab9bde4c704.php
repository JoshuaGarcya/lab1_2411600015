<?php $__env->startSection('content'); ?>

<div class="container" style="max-width: 760px;">

    <div class="pb-2 mb-4 border-bottom">
        <h2 class="mb-1">Record Attendance Transaction</h2>
        <p class="text-muted mb-0">
            Log an absence, or restore allowance (for example, an approved excuse letter).
        </p>
    </div>

    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="card shadow-sm">
        <div class="card-body">

            <form method="POST" action="<?php echo e(route('attendance-transactions.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="course_id" class="form-label">Course</label>
                    <select id="course_id" name="course_id" class="form-select" required>
                        <option value="">Select a course…</option>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($course->id); ?>"
                                    data-remaining="<?php echo e($course->absences_remaining); ?>"
                                    data-allowed="<?php echo e($course->absences_allowed); ?>"
                                    <?php if(old('course_id', $selectedCourse) == $course->id): echo 'selected'; endif; ?>>
                                <?php echo e($course->course_code); ?> — <?php echo e($course->course_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['course_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div id="allowance-info" class="form-text"></div>
                </div>

                <div class="mb-3">
                    <label class="form-label d-block">Transaction Type</label>

                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="type" id="type_absence"
                               value="absence" <?php if(old('type', 'absence') === 'absence'): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="type_absence">Absence (uses allowance)</label>
                    </div>

                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="type" id="type_restore"
                               value="restore" <?php if(old('type') === 'restore'): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="type_restore">Restore (excused / makeup)</label>
                    </div>

                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="quantity" class="form-label">Number of absences</label>
                    <input type="number" id="quantity" name="quantity" class="form-control"
                           min="1" value="<?php echo e(old('quantity', 1)); ?>" required>
                    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="reference_number" class="form-label">Reference Number (optional)</label>
                    <input type="text" id="reference_number" name="reference_number" class="form-control"
                           maxlength="50" value="<?php echo e(old('reference_number')); ?>"
                           placeholder="Example: Excuse letter #12, class of Oct 3">
                    <?php $__errorArgs = ['reference_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="notes" class="form-label">Notes (optional)</label>
                    <textarea id="notes" name="notes" rows="3" maxlength="500"
                              class="form-control"><?php echo e(old('notes')); ?></textarea>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" id="submit-btn" class="btn btn-primary">Save Transaction</button>
                    <a href="<?php echo e(route('attendance-transactions.index')); ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    (function () {
        const course = document.getElementById('course_id');
        const quantity = document.getElementById('quantity');
        const info = document.getElementById('allowance-info');
        const submit = document.getElementById('submit-btn');
        const types = document.querySelectorAll('input[name="type"]');

        function selectedType() {
            return document.querySelector('input[name="type"]:checked').value;
        }

        // Shows the current allowance and caps the quantity for the chosen type
        function refresh() {
            const option = course.options[course.selectedIndex];

            if (!option || !option.dataset.remaining) {
                info.textContent = '';
                quantity.removeAttribute('max');
                submit.disabled = false;
                return;
            }

            const remaining = parseInt(option.dataset.remaining, 10);
            const allowed = parseInt(option.dataset.allowed, 10);
            const used = allowed - remaining;
            const max = selectedType() === 'absence' ? remaining : used;

            info.textContent = 'Current allowance: ' + remaining + ' of ' + allowed +
                ' absences remaining. Maximum for this transaction: ' + max + '.';

            quantity.max = max;
            quantity.min = max > 0 ? 1 : 0;

            if (max === 0) {
                info.textContent += ' Nothing to ' + (selectedType() === 'absence' ? 'record' : 'restore') + '.';
                submit.disabled = true;
            } else {
                submit.disabled = false;

                if (parseInt(quantity.value, 10) > max) {
                    quantity.value = max;
                }
            }
        }

        course.addEventListener('change', refresh);
        types.forEach(function (t) { t.addEventListener('change', refresh); });
        refresh();
    })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/attendance/create.blade.php ENDPATH**/ ?>