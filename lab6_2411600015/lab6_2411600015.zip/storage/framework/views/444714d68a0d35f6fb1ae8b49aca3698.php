<?php $__env->startSection('content'); ?>

<div class="container">

    <h1><?php echo e($course->course_name); ?></h1>

    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <p><strong>Course Code:</strong> <?php echo e($course->course_code); ?></p>

    <p><strong>Category:</strong> <?php echo e($course->category); ?></p>

    <p><strong>Units:</strong> <?php echo e($course->units); ?></p>

    <p><strong>Grade:</strong> <?php echo e(number_format($course->grade, 2)); ?></p>

    <p><strong>Status:</strong> <?php echo e($course->status); ?></p>

    <p><strong>Quality Points:</strong> <?php echo e($course->quality_points); ?></p>

    <p><strong>Instructor:</strong> <?php echo e($course->instructor); ?></p>

    <p><strong>Attendance:</strong> <?php echo e($course->attendance_rate); ?>%</p>

    <p>
        <strong>Absence Allowance:</strong>
        <?php echo e($course->absences_remaining); ?> of <?php echo e($course->absences_allowed); ?> remaining
        <span class="badge bg-<?php echo e($course->allowance_status_color); ?> <?php echo e($course->allowance_status_color === 'warning' ? 'text-dark' : ''); ?>">
            <?php echo e($course->allowance_status); ?>

        </span>
    </p>

    <a href="<?php echo e(route('courses.edit', $course)); ?>" class="btn btn-primary">
        Edit
    </a>

    <a href="<?php echo e(route('attendance-transactions.create', ['course_id' => $course->id])); ?>" class="btn btn-outline-primary">
        Record Transaction
    </a>

    <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-secondary">
        Back to Courses
    </a>


    <!-- Transaction history with running balance -->
    <div class="card shadow-sm mt-4">

        <div class="card-header">
            <h5 class="mb-0">Attendance History</h5>
        </div>

        <div class="card-body">

            <form method="GET" action="<?php echo e(route('courses.show', $course)); ?>" class="mb-3">
                <div class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label for="date_from" class="form-label">From</label>
                        <input type="date" id="date_from" name="date_from" class="form-control"
                               value="<?php echo e(request('date_from')); ?>">
                    </div>

                    <div class="col-md-3">
                        <label for="date_to" class="form-label">To</label>
                        <input type="date" id="date_to" name="date_to" class="form-control"
                               value="<?php echo e(request('date_to')); ?>">
                    </div>

                    <div class="col-md-4 d-flex gap-2">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="<?php echo e(route('courses.show', $course)); ?>" class="btn btn-secondary">Reset</a>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="text-danger small mt-2"><?php echo e($errors->first()); ?></div>
                <?php endif; ?>
            </form>

            <?php if($transactions->count()): ?>

                <div class="table-responsive">
                    <table class="table table-striped align-middle">
                        <thead>
                            <tr>
                                <th>Date / Time</th>
                                <th>Type</th>
                                <th class="text-end">Quantity</th>
                                <th class="text-end">Balance After</th>
                                <th>Reference</th>
                                <th>Recorded By</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('attendance-transactions.show', $transaction)); ?>">
                                            <?php echo e($transaction->created_at->format('M d, Y h:i A')); ?>

                                        </a>
                                    </td>

                                    <td>
                                        <span class="badge bg-<?php echo e($transaction->type_badge); ?> <?php echo e($transaction->type_badge === 'info' ? 'text-dark' : ''); ?>">
                                            <?php echo e($transaction->type_label); ?>

                                        </span>
                                    </td>

                                    <td class="text-end fw-bold <?php echo e($transaction->quantity > 0 ? 'text-success' : 'text-danger'); ?>">
                                        <?php echo e($transaction->signed_quantity); ?>

                                    </td>

                                    <td class="text-end"><?php echo e($transaction->running_balance); ?></td>

                                    <td><?php echo e($transaction->reference_number ?? '—'); ?></td>

                                    <td><?php echo e($transaction->user->name ?? 'Deleted user'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            <?php else: ?>
                <p class="text-muted mb-0">No transactions recorded for this course yet.</p>
            <?php endif; ?>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/courses/show.blade.php ENDPATH**/ ?>