<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Dashboard Header -->
    <div class="d-flex justify-content-between align-items-center pb-2 mb-4 border-bottom">
        <div>
            <h2 class="mb-1">Dashboard</h2>
            <p class="text-muted mb-0">
    <?php
        $hour = now()->hour;

        if ($hour < 12) {
            $greeting = 'Good Morning';
        } elseif ($hour < 18) {
            $greeting = 'Good Afternoon';
        } else {
            $greeting = 'Good Evening';
        }
    ?>

    <?php echo e($greeting); ?>, <?php echo e(Auth::user()->name); ?>!
</p>
        </div>

        <div class="text-end">
            <small class="text-muted d-block">
                Last updated: <span id="last-updated">just now</span>
            </small>
            <small id="live-status" class="text-success">● Live</small>
        </div>
    </div>


    <!-- Course Attention Alert -->
    <?php if($coursesNeedingAttention->count()): ?>

        <div class="alert alert-warning shadow-sm mb-4" role="alert">

            <div class="d-flex align-items-start">

                <div class="me-3 fs-4">
                    ⚠️
                </div>

                <div class="flex-grow-1">

                    <h5 class="alert-heading mb-1">
                        Courses Need Attention
                    </h5>

                    <p class="mb-2">
                        <?php echo e($coursesNeedingAttention->count()); ?>

                        course(s) may need your attention.
                    </p>

                    <ul class="mb-0">

                        <?php $__currentLoopData = $coursesNeedingAttention; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li class="mb-1">

                                <strong>
                                    <?php echo e($course->course_code); ?>

                                </strong>

                                — <?php echo e($course->course_name); ?>


                                <?php if($course->grade < 3.0): ?>

                                    <span class="text-danger ms-1">
                                        Grade: <?php echo e(number_format($course->grade, 2)); ?>

                                    </span>

                                <?php endif; ?>

                                <?php if($course->attendance_rate < 80): ?>

                                    <span class="text-danger ms-1">
                                        Attendance: <?php echo e($course->attendance_rate); ?>%
                                    </span>

                                <?php endif; ?>

                            </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>

                </div>

            </div>

        </div>

    <?php endif; ?>


    <!-- Statistics -->
    <div class="row g-4 mb-4">

        <!-- GPA -->
        <div class="col-md-6 col-xl-3">

            <div class="card shadow-sm h-100 dashboard-stat-card">

                <div class="card-body">

                    <p class="text-muted stat-label">
                        GPA
                    </p>

                    <h2 id="stat1-value" class="stat-value mb-0">
                        <?php echo e($averageGrade); ?>

                    </h2>

                </div>

            </div>

        </div>


        <!-- Courses -->
        <div class="col-md-6 col-xl-3">

            <div class="card shadow-sm h-100 dashboard-stat-card">

                <div class="card-body">

                    <p class="text-muted stat-label">
                        Courses
                    </p>

                    <h2 id="stat2-value" class="stat-value mb-0">
                        <?php echo e($totalCourses); ?>

                    </h2>

                </div>

            </div>

        </div>


       <!-- At Risk -->
<div class="col-md-6 col-xl-3">
    <div class="card shadow-sm h-100 dashboard-stat-card">
        <div class="card-body">
            <p class="text-muted stat-label">
                At Risk
            </p>

            <h2 id="stat3-value" class="stat-value mb-0">
                <?php echo e($atRiskCourses); ?>

            </h2>

            <small class="text-muted">
                Courses needing attention
            </small>
        </div>
    </div>
</div>


        <!-- Attendance -->
        <div class="col-md-6 col-xl-3">

            <div class="card shadow-sm h-100 dashboard-stat-card">

                <div class="card-body">

                    <p class="text-muted stat-label">
                        Attendance
                    </p>

                    <h2 id="stat4-value" class="stat-value mb-0">
                        <?php echo e($averageAttendance); ?>%
                    </h2>

                </div>

            </div>

        </div>

    </div>


    <!-- Charts -->
    <div class="row g-4 mb-4">

        <!-- Category Chart -->
        <div class="col-lg-6">

            <div class="card shadow-sm h-100">

                <div class="card-header">
                    <h5 class="mb-0">
                        Units by Course Category
                    </h5>
                </div>

                <div class="card-body">

                    <div style="height: 300px;">
                        <canvas id="categoryChart"></canvas>
                    </div>

                </div>

            </div>

        </div>


        <!-- Status Chart -->
        <div class="col-lg-6">

            <div class="card shadow-sm h-100">

                <div class="card-header">
                    <h5 class="mb-0">
                        Course Status Distribution
                    </h5>
                </div>

                <div class="card-body">

                    <div style="height: 300px;">
                        <canvas id="statusChart"></canvas>
                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- Top Courses -->
    <div class="card shadow-sm mb-4">

        <div class="card-header">
            <h5 class="mb-0">
                Top Courses by Grade
            </h5>
        </div>

        <div class="card-body">

            <div style="height: 350px;">
                <canvas id="topCoursesChart"></canvas>
            </div>

        </div>

    </div>


    <!-- Attendance by Course -->
    <div class="card shadow-sm mb-4">

        <div class="card-header">
            <h5 class="mb-0">
                Attendance by Course
            </h5>
        </div>

        <div class="card-body">

            <div style="height: 320px;">
                <canvas id="attendanceChart"></canvas>
            </div>

        </div>

    </div>


    <!-- Live allowance monitor -->
    <div id="live-config"
         data-stats-url="<?php echo e(route('api.dashboard.stats')); ?>"
         data-low-url="<?php echo e(route('api.courses.low-allowance')); ?>"
         data-recent-url="<?php echo e(route('api.transactions.recent')); ?>">
    </div>

    <div class="row g-4 mb-4">

        <!-- Low allowance alerts -->
        <div class="col-lg-5">
            <div class="card shadow-sm h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Low Allowance Alerts</h5>
                    <a href="<?php echo e(route('reports.index', ['report' => 'low'])); ?>" class="btn btn-sm btn-primary">Report</a>
                </div>

                <div class="card-body">
                    <p id="low-allowance-empty" class="text-muted mb-0 d-none">
                        No courses are near their absence limit.
                    </p>

                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Course</th>
                                    <th class="text-end">Left</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody id="low-allowance-body">
                                <tr><td colspan="3" class="text-muted">Loading…</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent transactions -->
        <div class="col-lg-7">
            <div class="card shadow-sm h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Transactions</h5>
                    <a href="<?php echo e(route('attendance-transactions.index')); ?>" class="btn btn-sm btn-primary">View All</a>
                </div>

                <div class="card-body">
                    <p id="recent-empty" class="text-muted mb-0 d-none">
                        No attendance transactions yet.
                    </p>

                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>When</th>
                                    <th>Course</th>
                                    <th>Type</th>
                                    <th class="text-end">Qty</th>
                                    <th>By</th>
                                </tr>
                            </thead>
                            <tbody id="recent-body">
                                <tr><td colspan="5" class="text-muted">Loading…</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <!-- Recent Courses -->
    <div class="card shadow-sm">

        <div class="card-header d-flex justify-content-between align-items-center">

            <h5 class="mb-0">
                Recent Courses
            </h5>

            <a href="<?php echo e(route('courses.index')); ?>"
               class="btn btn-sm btn-primary">
                View All
            </a>

        </div>


        <div class="card-body">

            <?php if($recentCourses->count()): ?>

                <div class="table-responsive">

                    <table class="table table-striped table-hover align-middle">

                        <thead>

                            <tr>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Category</th>
                                <th>Instructor</th>
                                <th>Grade</th>
                                <th>Status</th>
                            </tr>

                        </thead>


                        <tbody>

                            <?php $__currentLoopData = $recentCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>

                                    <td>
                                        <?php echo e($course->course_code); ?>

                                    </td>

                                    <td>
                                        <?php echo e($course->course_name); ?>

                                    </td>

                                    <td>
                                        <?php echo e($course->category); ?>

                                    </td>

                                    <td>
                                        <?php echo e($course->instructor); ?>

                                    </td>

                                    <td>
                                        <?php echo e(number_format($course->grade, 2)); ?>

                                    </td>

                                    <td>

                                        <?php if($course->status === 'Passing'): ?>

                                            <span class="badge bg-success">
                                                Passing
                                            </span>

                                        <?php elseif($course->status === 'At Risk'): ?>

                                            <span class="badge bg-warning text-dark">
                                                At Risk
                                            </span>

                                        <?php else: ?>

                                            <span class="badge bg-danger">
                                                Failing
                                            </span>

                                        <?php endif; ?>

                                    </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>

                </div>

            <?php else: ?>

                <p class="text-muted mb-0">
                    No courses have been added yet.
                </p>

            <?php endif; ?>

        </div>

    </div>

</div>


<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="<?php echo e(asset('js/charts.js')); ?>"></script>
<script src="<?php echo e(asset('js/dashboard-live.js')); ?>"></script>


<script>

    const categoryData = <?php echo json_encode($categorySummary, 15, 512) ?>;
    
    const statusData = <?php echo json_encode($statusStats, 15, 512) ?>;

    const coursesData = <?php echo json_encode($recentCourses, 15, 512) ?>;

    const attendanceData = <?php echo json_encode($attendanceByCourse, 15, 512) ?>;


    dashboardCharts.renderAll(
        categoryData,
        statusData,
        coursesData,
        attendanceData
    );

    // Start polling the JSON endpoints every 30 seconds
    dashboardLive.start(30000);

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/dashboard.blade.php ENDPATH**/ ?>