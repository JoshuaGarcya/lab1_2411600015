<?php echo csrf_field(); ?>

<div class="row g-3">

    <div class="col-md-6">
        <label for="course_code" class="form-label">
            Course Code
        </label>

        <input
            type="text"
            id="course_code"
            name="course_code"
            class="form-control"
            value="<?php echo e(old('course_code', $course->course_code ?? '')); ?>"
            <?php if(isset($course)): ?> readonly <?php endif; ?>
            placeholder="Example: IT101"
        >

        <?php $__errorArgs = ['course_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <div class="col-md-6">
        <label for="course_name" class="form-label">
            Course Name
        </label>

        <input
            type="text"
            id="course_name"
            name="course_name"
            class="form-control"
            value="<?php echo e(old('course_name', $course->course_name ?? '')); ?>"
            placeholder="Example: Web Systems and Technologies"
        >

        <?php $__errorArgs = ['course_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <div class="col-md-6">
        <label for="category" class="form-label">
            Category
        </label>

        <select id="category" name="category" class="form-select">

            <?php $__currentLoopData = ['Major', 'Minor', 'Gen Ed', 'Elective']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option
                    value="<?php echo e($cat); ?>"
                    <?php if(old('category', $course->category ?? '') === $cat): echo 'selected'; endif; ?>
                >
                    <?php echo e($cat); ?>

                </option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <div class="col-md-3">
        <label for="units" class="form-label">
            Units
        </label>

        <input
            type="number"
            id="units"
            name="units"
            class="form-control"
            min="1"
            max="6"
            value="<?php echo e(old('units', $course->units ?? '')); ?>"
            placeholder="3"
        >

        <?php $__errorArgs = ['units'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <div class="col-md-3">
        <label for="grade" class="form-label">
            Grade
        </label>

        <input
            type="number"
            id="grade"
            name="grade"
            class="form-control"
            min="0"
            max="4"
            step="0.01"
            value="<?php echo e(old('grade', $course->grade ?? '')); ?>"
            placeholder="3.50"
        >

        <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <div class="col-md-6">
        <label for="instructor" class="form-label">
            Instructor
        </label>

        <input
            type="text"
            id="instructor"
            name="instructor"
            class="form-control"
            value="<?php echo e(old('instructor', $course->instructor ?? '')); ?>"
            placeholder="Example: Prof. Santos"
        >

        <?php $__errorArgs = ['instructor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <div class="col-md-6">
        <label for="attendance_rate" class="form-label">
            Attendance Rate
        </label>

        <div class="input-group">

            <input
                type="number"
                id="attendance_rate"
                name="attendance_rate"
                class="form-control"
                min="0"
                max="100"
                value="<?php echo e(old('attendance_rate', $course->attendance_rate ?? '')); ?>"
                placeholder="95"
            >

            <span class="input-group-text">
                %
            </span>

        </div>

        <?php $__errorArgs = ['attendance_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>


<div class="mt-4 pt-3 border-top">

    <button type="submit" class="btn btn-primary px-4">
        <?php echo e($buttonText ?? 'Save Course'); ?>

    </button>

    <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-secondary ms-2">
        Cancel
    </a>

</div><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/courses/_form.blade.php ENDPATH**/ ?>