<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center pb-2 mb-4 border-bottom">
        <div>
            <h2 class="mb-1">Attendance Log</h2>
            <p class="text-muted mb-0">
                Every absence, restored allowance and adjustment, with who recorded it.
            </p>
        </div>

        <div class="d-flex gap-2">
            <?php if(Auth::user()->is_admin): ?>
                <a href="<?php echo e(route('adjustments.create')); ?>" class="btn btn-outline-primary">
                    Adjust Count
                </a>
            <?php endif; ?>

            <a href="<?php echo e(route('attendance-transactions.create')); ?>" class="btn btn-primary">
                + Record Transaction
            </a>
        </div>
    </div>

    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Filters -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('attendance-transactions.index')); ?>">
                <div class="row g-3 align-items-end">

                    <div class="col-md-3">
                        <label for="course_id" class="form-label">Course</label>
                        <select id="course_id" name="course_id" class="form-select">
                            <option value="">All Courses</option>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($course->id); ?>" <?php if(request('course_id') == $course->id): echo 'selected'; endif; ?>>
                                    <?php echo e($course->course_code); ?> — <?php echo e($course->course_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="type" class="form-label">Type</label>
                        <select id="type" name="type" class="form-select">
                            <option value="">All Types</option>
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type); ?>" <?php if(request('type') === $type): echo 'selected'; endif; ?>>
                                    <?php echo e(ucfirst($type)); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="date_from" class="form-label">From</label>
                        <input type="date" id="date_from" name="date_from" class="form-control"
                               value="<?php echo e(request('date_from')); ?>">
                    </div>

                    <div class="col-md-2">
                        <label for="date_to" class="form-label">To</label>
                        <input type="date" id="date_to" name="date_to" class="form-control"
                               value="<?php echo e(request('date_to')); ?>">
                    </div>

                    <div class="col-md-3 d-flex gap-2">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="<?php echo e(route('attendance-transactions.index')); ?>" class="btn btn-secondary">Reset</a>
                    </div>

                </div>

                <?php if($errors->any()): ?>
                    <div class="text-danger small mt-2"><?php echo e($errors->first()); ?></div>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card shadow-sm">
        <div class="card-body">

            <?php if($transactions->count()): ?>

                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Date / Time</th>
                                <th>Course</th>
                                <th>Type</th>
                                <th class="text-end">Quantity</th>
                                <th>Reference</th>
                                <th>Recorded By</th>
                                <th>Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($transaction->created_at->format('M d, Y h:i A')); ?></td>

                                    <td>
                                        <?php if($transaction->course): ?>
                                            <a href="<?php echo e(route('courses.show', $transaction->course)); ?>">
                                                <?php echo e($transaction->course->course_code); ?>

                                            </a>
                                            <div class="small text-muted"><?php echo e($transaction->course->course_name); ?></div>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <span class="badge bg-<?php echo e($transaction->type_badge); ?> <?php echo e($transaction->type_badge === 'info' ? 'text-dark' : ''); ?>">
                                            <?php echo e($transaction->type_label); ?>

                                        </span>
                                    </td>

                                    <td class="text-end fw-bold <?php echo e($transaction->quantity > 0 ? 'text-success' : 'text-danger'); ?>">
                                        <?php echo e($transaction->signed_quantity); ?>

                                    </td>

                                    <td><?php echo e($transaction->reference_number ?? '—'); ?></td>

                                    <td><?php echo e($transaction->user->name ?? 'Deleted user'); ?></td>

                                    <td>
                                        <div class="d-flex gap-1">
                                            <a href="<?php echo e(route('attendance-transactions.show', $transaction)); ?>"
                                               class="btn btn-sm btn-outline-primary">View</a>

                                            <?php if(Auth::user()->is_admin): ?>
                                                <form method="POST"
                                                      action="<?php echo e(route('attendance-transactions.destroy', $transaction)); ?>"
                                                      onsubmit="return confirm('Delete this transaction? Its effect on the course will be reversed.');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-3">
                    <?php echo e($transactions->links('pagination::bootstrap-5')); ?>

                </div>

            <?php else: ?>
                <p class="text-muted mb-0">No transactions match your filters.</p>
            <?php endif; ?>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/attendance/index.blade.php ENDPATH**/ ?>