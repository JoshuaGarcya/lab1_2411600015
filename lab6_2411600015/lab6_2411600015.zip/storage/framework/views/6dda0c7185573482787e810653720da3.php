

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center pb-2 mb-4 border-bottom">
        <div>
            <h2 class="mb-1">Add Course</h2>
            <p class="text-muted mb-0">
                Add a new course to your student portal.
            </p>
        </div>

        <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-secondary">
            Back to Courses
        </a>
    </div>


    <div class="card shadow-sm course-form-card">

        <div class="card-header">
            <h5 class="mb-0">Course Information</h5>
        </div>

        <div class="card-body">

            <form method="POST" action="<?php echo e(route('courses.store')); ?>">

                <?php echo $__env->make('courses._form', [
                    'buttonText' => 'Add Course'
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </form>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600015\lab6_2411600015\resources\views/courses/create.blade.php ENDPATH**/ ?>