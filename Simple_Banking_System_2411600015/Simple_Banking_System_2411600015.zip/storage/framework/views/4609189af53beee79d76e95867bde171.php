<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center pb-2 mb-4 border-bottom">
        <div>
            <h2 class="mb-1">Transactions</h2>
            <p class="text-muted mb-0">Deposits and withdrawals.</p>
        </div>

        <a href="<?php echo e(route('transactions.create')); ?>" class="btn btn-primary">+ New Transaction</a>
    </div>

    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Date</th>
                <th>Account</th>
                <th>Type</th>
                <th class="text-end">Amount</th>
                <th>Reference</th>
                <th>Notes</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($transaction->created_at->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($transaction->account->account_number); ?></td>
                    <td><?php echo e(ucfirst($transaction->type)); ?></td>
                    <td class="text-end"><?php echo e(number_format($transaction->amount, 2)); ?></td>
                    <td><?php echo e($transaction->reference_number); ?></td>
                    <td><?php echo e($transaction->notes); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center text-muted">No transactions yet.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($transactions->links('pagination::bootstrap-5')); ?>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Simple_Banking_System_2411600015\resources\views/transactions/index.blade.php ENDPATH**/ ?>