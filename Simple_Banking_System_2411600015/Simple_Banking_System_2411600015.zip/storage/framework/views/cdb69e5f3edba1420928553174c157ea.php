<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center pb-2 mb-4 border-bottom">
    <h2 class="mb-0">Notifications</h2>

    <form method="POST" action="<?php echo e(route('notifications.readAll')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-outline-primary btn-sm">Mark all as read</button>
    </form>
</div>

<?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<ul class="list-group mb-3">
    <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li class="list-group-item <?php echo e($notification->read_at ? '' : 'list-group-item-warning'); ?>">
            <strong>Low balance</strong>
            <?php if (! ($notification->read_at)): ?>
                <span class="badge bg-danger">new</span>
            <?php endif; ?>
            <div><?php echo e($notification->data['message'] ?? ''); ?></div>
            <div class="small text-muted"><?php echo e($notification->created_at->format('Y-m-d H:i')); ?></div>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <li class="list-group-item text-muted">No notifications.</li>
    <?php endif; ?>
</ul>

<?php echo e($notifications->links('pagination::bootstrap-5')); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Simple_Banking_System_2411600015\resources\views/notifications/index.blade.php ENDPATH**/ ?>