<?php $__env->startSection('content'); ?>

<div class="container" style="max-width: 760px;">

    <div class="pb-2 mb-4 border-bottom">
        <h2 class="mb-1">New Transaction</h2>
        <p class="text-muted mb-0">Make a deposit or a withdrawal.</p>
    </div>

    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if($accounts->isEmpty()): ?>
        <div class="alert alert-warning">
            You do not have a bank account yet.
        </div>
    <?php else: ?>
        <form method="POST" action="<?php echo e(route('transactions.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="account_id" class="form-label">Account</label>
                <select id="account_id" name="account_id" class="form-select" required>
                    <option value="">Select an account…</option>
                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($account->id); ?>" <?php if(old('account_id') == $account->id): echo 'selected'; endif; ?>>
                            <?php echo e($account->account_number); ?>

                            — balance <?php echo e(number_format($account->balance, 2)); ?>

                            (minimum <?php echo e(number_format($account->minimum_balance, 2)); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label for="type" class="form-label">Type</label>
                <select id="type" name="type" class="form-select" required>
                    <option value="deposit" <?php if(old('type', 'deposit') === 'deposit'): echo 'selected'; endif; ?>>Deposit</option>
                    <option value="withdrawal" <?php if(old('type') === 'withdrawal'): echo 'selected'; endif; ?>>Withdrawal</option>
                </select>
                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label for="amount" class="form-label">Amount</label>
                <input type="number" id="amount" name="amount" class="form-control"
                       min="1" step="0.01" value="<?php echo e(old('amount')); ?>" required>
                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label for="notes" class="form-label">Notes (optional)</label>
                <textarea id="notes" name="notes" rows="3" maxlength="500"
                          class="form-control"><?php echo e(old('notes')); ?></textarea>
                <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Save Transaction</button>
                <a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Simple_Banking_System_2411600015\resources\views/transactions/create.blade.php ENDPATH**/ ?>