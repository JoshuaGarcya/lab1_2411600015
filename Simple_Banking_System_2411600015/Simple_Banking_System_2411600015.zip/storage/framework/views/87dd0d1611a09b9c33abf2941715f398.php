<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Simple_Banking_System_2411600015\resources\views/partials/flash.blade.php ENDPATH**/ ?>