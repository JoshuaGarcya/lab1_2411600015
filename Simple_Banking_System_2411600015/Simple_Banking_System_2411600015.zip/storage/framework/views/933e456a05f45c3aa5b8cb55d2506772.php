<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Simple Banking System</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand navbar-dark bg-primary px-3">
    <a class="navbar-brand" href="<?php echo e(route('bank.dashboard')); ?>">Simple Banking System</a>

    <?php if(auth()->guard()->check()): ?>
        <ul class="navbar-nav me-auto">
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('bank.dashboard')); ?>">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('transactions.index')); ?>">Transactions</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('transactions.create')); ?>">New Transaction</a></li>
        </ul>

        <?php $unread = Auth::user()->unreadNotifications()->count(); ?>

        <span class="navbar-text me-3">
            <?php echo e(Auth::user()->name); ?><?php if(Auth::user()->isAdmin()): ?> (admin)<?php endif; ?>
        </span>

        <a class="nav-link text-white me-3" href="<?php echo e(route('notifications.index')); ?>">
            Notifications
            <?php if($unread > 0): ?>
                <span class="badge bg-danger"><?php echo e($unread); ?></span>
            <?php endif; ?>
        </a>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-sm btn-light">Logout</button>
        </form>
    <?php endif; ?>
</nav>

<main class="container py-4">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Simple_Banking_System_2411600015\resources\views/layouts/app.blade.php ENDPATH**/ ?>